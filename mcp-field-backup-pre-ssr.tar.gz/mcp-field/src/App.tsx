import { MotionConfig } from 'motion/react'
import { useEffect } from 'react'
import { BrowserRouter, Outlet, Route, Routes, useLocation } from 'react-router'
import { Footer } from './components/Footer'
import { Nav } from './components/Nav'
import { I18nProvider } from './i18n/context'
import { LOCALE_META, LOCALES, type Locale } from './i18n/locales'
import AgentDetail from './pages/AgentDetail'
import Agents from './pages/Agents'
import ClientDetail from './pages/ClientDetail'
import Clients from './pages/Clients'
import CliDetail from './pages/CliDetail'
import Clis from './pages/Clis'
import Home from './pages/Home'
import SkillDetail from './pages/SkillDetail'
import Skills from './pages/Skills'
import LoopDetail from './pages/LoopDetail'
import Loops from './pages/Loops'
import ServerDetail from './pages/ServerDetail'
import Servers from './pages/Servers'

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])
  return null
}

function Layout({ locale }: { locale: Locale }) {
  return (
    <I18nProvider locale={locale}>
      <Nav />
      <main>
        <Outlet />
      </main>
      <Footer />
    </I18nProvider>
  )
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <BrowserRouter>
        <ScrollToTop />
        <Routes>
          {LOCALES.map((l) => (
            <Route key={l} path={LOCALE_META[l].prefix || '/'} element={<Layout locale={l} />}>
              <Route index element={<Home />} />
              <Route path="servers" element={<Servers />} />
              <Route path="servers/:slug" element={<ServerDetail />} />
              <Route path="remote-servers" element={<Servers remote />} />
              <Route path="clients" element={<Clients />} />
              <Route path="clients/:slug" element={<ClientDetail />} />
              <Route path="cli" element={<Clis />} />
              <Route path="cli/:slug" element={<CliDetail />} />
              <Route path="skills" element={<Skills />} />
              <Route path="skills/:slug" element={<SkillDetail />} />
              <Route path="loops" element={<Loops />} />
              <Route path="loops/:slug" element={<LoopDetail />} />
              <Route path="agents" element={<Agents />} />
              <Route path="agents/:slug" element={<AgentDetail />} />
            </Route>
          ))}
        </Routes>
      </BrowserRouter>
    </MotionConfig>
  )
}
