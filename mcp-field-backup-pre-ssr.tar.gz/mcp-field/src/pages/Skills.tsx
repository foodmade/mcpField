import { ApiDirectory } from '../components/directory/ApiDirectory'
import { SkillCard, SkillRow } from '../components/directory/SkillItems'
import { useI18n } from '../i18n/context'
import type { SkillItem } from '../lib/api/entities'
import { skillCategories, type ViewKey } from '../lib/categories'

const Card = ({ item }: { item: SkillItem }) => <SkillCard s={item} />
const Row = ({ item }: { item: SkillItem }) => <SkillRow s={item} />
const VIEWS: ViewKey[] = ['official', 'featured', 'verified']

export default function Skills() {
  const { m } = useI18n()
  return <ApiDirectory kind="skill" text={m.dirs.skills} categories={skillCategories} views={VIEWS} Card={Card} Row={Row} />
}
