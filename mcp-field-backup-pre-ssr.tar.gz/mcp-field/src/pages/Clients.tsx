import { ApiDirectory } from '../components/directory/ApiDirectory'
import { ClientCard, ClientRow } from '../components/directory/ClientItems'
import { useI18n } from '../i18n/context'
import type { ClientItem } from '../lib/api/entities'
import { clientCategories } from '../lib/categories'

const Card = ({ item }: { item: ClientItem }) => <ClientCard c={item} />
const Row = ({ item }: { item: ClientItem }) => <ClientRow c={item} />

/** 客户端目录：筛选、搜索、排序、分页都交给后端接口 */
export default function Clients() {
  const { m } = useI18n()
  return <ApiDirectory kind="client" text={m.dirs.clients} categories={clientCategories} Card={Card} Row={Row} />
}
