import { useMemo, type ReactNode } from 'react'
import { useI18n } from '../../i18n/context'
import { fetchFacets, fetchList, type ItemOf, type Kind, type ListParams } from '../../lib/api/entities'
import { useApi, useDebounced } from '../../lib/api/useApi'
import { categoryParam, PAGE_SIZE, type Category, type SortKey, type TypeOption, type ViewKey } from '../../lib/categories'
import { DirectoryLayout, type DirText } from './DirectoryLayout'
import { useDirectoryParams } from './useDirectoryParams'

/** 页面排序 → 接口排序：最热门按该类型的热度指标（星数 / 安装量 / 浏览量） */
const SORT: Record<SortKey, NonNullable<ListParams['sort']>> = { hot: 'popular', new: 'newest', name: 'name' }

type Props<K extends Kind> = {
  kind: K
  text: DirText
  categories: Category[]
  /** 侧栏快捷视图，默认精选与已认证 */
  views?: ViewKey[]
  /** 侧栏的子类型筛选（Agent：产品 / 模板）；不传则不显示 */
  types?: TypeOption[]
  /** 只看远程服务（远程服务目录） */
  remote?: boolean
  Card: (p: { item: ItemOf[K] }) => ReactNode
  Row: (p: { item: ItemOf[K] }) => ReactNode
}

/**
 * 接口驱动的目录页：URL 里的分类、视图、搜索、排序、页码都转成接口参数，
 * 筛选、搜索、分页都由后端完成；侧栏计数来自 facets 接口。
 */
export function ApiDirectory<K extends Kind>({ kind, text, categories, views = ['featured', 'verified'], types = [], remote, Card, Row }: Props<K>) {
  const { locale } = useI18n()
  const slugs = useMemo(() => new Set(categories.map((c) => c.slug)), [categories])
  const p = useDirectoryParams((slug) => slugs.has(slug), views, types.map((t) => t.value))
  const q = useDebounced(p.q.trim(), 250)

  const params: ListParams = {
    page: p.page,
    pageSize: PAGE_SIZE,
    q: q || undefined,
    category: categoryParam(p.category),
    featured: p.view === 'featured' || undefined,
    verified: p.view === 'verified' || undefined,
    official: p.view === 'official' || undefined,
    remote: remote || undefined,
    type: p.type ?? undefined,
    sort: SORT[p.sort],
    locale,
  }
  const list = useApi(`${kind}:list:${JSON.stringify(params)}`, (signal) => fetchList(kind, params, signal), { keepPrevious: true })
  const facets = useApi(`${kind}:facets:${remote ? 'remote' : 'all'}`, (signal) => fetchFacets(kind, remote ? { remote: true } : {}, signal))

  const counts = useMemo(() => {
    const f = facets.data
    const byCat: Record<string, number> = {}
    for (const c of f?.categories ?? []) {
      const slug = c.slug && slugs.has(c.slug) ? c.slug : 'other'
      byCat[slug] = (byCat[slug] ?? 0) + c.count
    }
    const byType = Object.fromEntries((f?.types ?? []).map((t) => [t.value, t.count]))
    return { all: f?.total ?? 0, byView: f?.views ?? { official: 0, featured: 0, verified: 0 }, byCat, byType }
  }, [facets.data, slugs])

  // 远程服务目录只显示有条目的分类
  const visible = remote && facets.data ? categories.filter((c) => (counts.byCat[c.slug] ?? 0) > 0 || c.slug === p.category) : categories

  return (
    <DirectoryLayout
      text={text}
      categories={visible}
      views={views}
      types={types}
      params={p}
      counts={counts}
      items={list.data?.data ?? []}
      total={list.data?.meta.total ?? 0}
      page={list.data?.meta.page ?? p.page}
      pageSize={PAGE_SIZE}
      Card={Card}
      Row={Row}
      status={list.loading ? 'loading' : list.error ? 'error' : 'ready'}
      onRetry={() => {
        list.reload()
        facets.reload()
      }}
    />
  )
}
