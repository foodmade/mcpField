/** 后端接口的基础地址：开发时经 Vite 代理转发到 localhost:3100 */
const BASE = import.meta.env.VITE_API_BASE ?? '/api'

export class ApiError extends Error {
  readonly status: number
  readonly code: string

  constructor(status: number, code: string, message: string) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.code = code
  }

  get notFound() {
    return this.status === 404
  }
}

export type Query = Record<string, string | number | boolean | undefined | null>

export async function apiGet<T>(path: string, query: Query = {}, signal?: AbortSignal): Promise<T> {
  const qs = new URLSearchParams()
  for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== null && v !== '') qs.set(k, String(v))
  const url = `${BASE}${path}${qs.size ? `?${qs}` : ''}`

  let res: Response
  try {
    res = await fetch(url, { signal, headers: { accept: 'application/json' } })
  } catch (error) {
    if (signal?.aborted) throw error
    throw new ApiError(0, 'network_error', '无法连接到服务器')
  }
  const body = (await res.json().catch(() => null)) as { error?: { code?: string; message?: string } } | null
  if (!res.ok) throw new ApiError(res.status, body?.error?.code ?? 'http_error', body?.error?.message ?? res.statusText)
  return body as T
}
