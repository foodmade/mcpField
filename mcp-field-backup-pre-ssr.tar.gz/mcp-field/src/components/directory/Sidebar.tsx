import { motion } from 'motion/react'
import { CaretDown, CheckCircle, MagnifyingGlass, ShieldCheck, SquaresFour, Star, X } from '@phosphor-icons/react'
import { useState, type ReactNode } from 'react'
import clsx from 'clsx'
import { useI18n } from '../../i18n/context'
import type { Category, TypeOption, ViewKey } from '../../lib/categories'
import type { DirCounts } from './DirectoryLayout'

const COLLAPSED = 10
const VIEW_ICON: Record<ViewKey, [typeof Star, string]> = { official: [ShieldCheck, '#9FC6FF'], featured: [Star, '#F2C94C'], verified: [CheckCircle, '#3DDC97'] }

type Props = {
  categories: Category[]
  searchPh: string
  view: ViewKey | null
  category: string | null
  /** 子类型筛选，可以和视图、分类叠加 */
  type: string | null
  q: string
  views: ViewKey[]
  types: TypeOption[]
  counts: DirCounts
  onView: (v: ViewKey | null) => void
  onCategory: (c: string | null) => void
  onType: (t: string) => void
  onQuery: (q: string) => void
}

function Item({ active, icon, label, count, onClick, accent }: { active: boolean; icon: ReactNode; label: string; count: number; onClick: () => void; accent?: string }) {
  return (
    <button
      onClick={onClick}
      aria-current={active ? 'page' : undefined}
      className={clsx('group relative flex h-[38px] w-full items-center gap-2.5 rounded-[9px] px-2.5 text-left text-sm transition-colors', active ? 'font-semibold text-ink' : 'text-text2 hover:bg-white/[0.04] hover:text-ink')}
    >
      {active && (
        <motion.span
          layoutId="dir-active"
          className="absolute inset-0 rounded-[9px] border border-accent/20"
          style={{ background: 'linear-gradient(90deg, rgba(61,220,151,0.15), rgba(255,255,255,0.04))' }}
          transition={{ type: 'spring', stiffness: 420, damping: 34 }}
        />
      )}
      <span className="relative transition-transform duration-300 group-hover:scale-110" style={{ color: active ? '#3DDC97' : accent }}>{icon}</span>
      <span className="relative flex-1 truncate">{label}</span>
      <span className={clsx('relative tabular-nums text-xs', active ? 'text-accent' : 'text-text3')}>{count.toLocaleString('en-US')}</span>
    </button>
  )
}

/** 子类型项：可以和视图、分类同时选中，所以不用共享的选中动画，而是用描边表示 */
function TypeItem({ active, icon, label, count, onClick, accent }: { active: boolean; icon: ReactNode; label: string; count: number; onClick: () => void; accent: string }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={clsx(
        'group flex h-[38px] w-full items-center gap-2.5 rounded-[9px] border px-2.5 text-left text-sm transition-colors',
        active ? 'border-white/15 bg-white/[0.06] font-semibold text-ink' : 'border-transparent text-text2 hover:bg-white/[0.04] hover:text-ink',
      )}
    >
      <span className="transition-transform duration-300 group-hover:scale-110" style={{ color: accent }}>{icon}</span>
      <span className="flex-1 truncate">{label}</span>
      {active ? <X size={12} className="text-text3" /> : <span className="tabular-nums text-xs text-text3">{count.toLocaleString('en-US')}</span>}
    </button>
  )
}

const GroupTitle = ({ children }: { children: ReactNode }) => <div className="mb-1.5 px-2.5 text-[11px] font-medium uppercase tracking-[0.08em] text-text3">{children}</div>

export function Sidebar({ categories: serverCategories, searchPh, views, types, view, category, type, q, counts, onView, onCategory, onType, onQuery }: Props) {
  const { m, tr } = useI18n()
  const activeIdx = serverCategories.findIndex((c) => c.slug === category)
  const [expanded, setExpanded] = useState(false)
  const showAll = expanded || activeIdx >= COLLAPSED
  const cats = showAll ? serverCategories : serverCategories.slice(0, COLLAPSED)

  const chips: { key: string; label: string; active: boolean; onClick: () => void }[] = [
    { key: 'all', label: `${m.dir.all} ${counts.all}`, active: !view && !category, onClick: () => onCategory(null) },
    ...views.map((v) => ({ key: v, label: `${m.dir[v]} ${counts.byView[v]}`, active: view === v, onClick: () => onView(v) })),
    ...types.map((t) => ({ key: `type:${t.value}`, label: `${t.label} ${counts.byType?.[t.value] ?? 0}`, active: type === t.value, onClick: () => onType(t.value) })),
    ...serverCategories.map((c) => ({ key: c.slug, label: `${tr(c.name)} ${counts.byCat[c.slug] ?? 0}`, active: category === c.slug, onClick: () => onCategory(c.slug) })),
  ]

  const search = (
    <label className="flex h-[38px] items-center gap-2 rounded-[10px] border border-white/10 bg-white/[0.04] px-3 transition-colors focus-within:border-accent/50 focus-within:bg-white/[0.06]">
      <MagnifyingGlass size={15} className="shrink-0 text-text3" />
      <input value={q} onChange={(e) => onQuery(e.target.value)} placeholder={searchPh} aria-label={searchPh} className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-text3" />
      {q && (
        <button onClick={() => onQuery('')} aria-label={m.dir.clearSearch} className="text-text3 hover:text-ink"><X size={13} /></button>
      )}
    </label>
  )

  return (
    <>
    <div className="flex flex-col gap-3 lg:hidden">
      {search}
      <div className="-mx-6 flex gap-2 overflow-x-auto px-6 pb-1 [scrollbar-width:none]">
        {chips.map((c) => (
          <button key={c.key} onClick={c.onClick} className={clsx('shrink-0 whitespace-nowrap rounded-full border px-3 py-1.5 text-sm transition-colors', c.active ? 'border-accent/40 bg-accent/15 font-medium text-[#9FF0CB]' : 'border-white/10 text-text2')}>
            {c.label}
          </button>
        ))}
      </div>
    </div>
    <aside className="hidden flex-col gap-7 lg:flex lg:sticky lg:top-[132px] lg:max-h-[calc(100vh-150px)] lg:overflow-y-auto lg:pb-6 [scrollbar-width:none]">
      {search}

      <div>
        <GroupTitle>{m.dir.views}</GroupTitle>
        {views.map((v) => {
          const [Icon, accent] = VIEW_ICON[v]
          return <Item key={v} active={view === v} icon={<Icon size={16} weight={v === 'featured' ? 'fill' : 'regular'} />} accent={accent} label={m.dir[v]} count={counts.byView[v]} onClick={() => onView(v)} />
        })}
      </div>

      {types.length > 0 && (
        <div>
          <GroupTitle>{m.agent.typeGroup}</GroupTitle>
          {types.map((t) => (
            <TypeItem key={t.value} active={type === t.value} icon={<t.icon size={16} />} accent={t.color} label={t.label} count={counts.byType?.[t.value] ?? 0} onClick={() => onType(t.value)} />
          ))}
        </div>
      )}

      <div>
        <GroupTitle>{m.dir.categories}</GroupTitle>
        <Item active={!view && !category} icon={<SquaresFour size={16} />} label={m.dir.all} count={counts.all} onClick={() => onCategory(null)} />
        {cats.map((c) => (
          <motion.div key={c.slug} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }}>
            <Item active={category === c.slug} icon={<c.icon size={16} />} accent={c.color} label={tr(c.name)} count={counts.byCat[c.slug] ?? 0} onClick={() => onCategory(c.slug)} />
          </motion.div>
        ))}
        {activeIdx < COLLAPSED && serverCategories.length > COLLAPSED && (
          <button onClick={() => setExpanded((e) => !e)} className="mt-1 flex items-center gap-1.5 px-2.5 py-1.5 text-sm text-text2 hover:text-ink">
            {expanded ? m.dir.collapse : m.dir.expand(serverCategories.length)}
            <CaretDown size={12} className={clsx('transition-transform duration-300', expanded && 'rotate-180')} />
          </button>
        )}
      </div>
    </aside>
    </>
  )
}
