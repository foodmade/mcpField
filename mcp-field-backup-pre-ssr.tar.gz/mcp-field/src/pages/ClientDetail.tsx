import { Buildings, CalendarBlank, ClockCounterClockwise, Cpu, Scales, SquaresFour, Star } from '@phosphor-icons/react'
import { useParams } from 'react-router'
import { Comments } from '../components/Comments'
import {
  AboutSection, DetailBody, DetailGate, EntityHeader, InfoSection, ReadmeSection, RelatedSection, useDateFormat, useEntityDetail,
} from '../components/detail/EntityDetail'
import { useI18n } from '../i18n/context'
import type { ClientDetail as Detail } from '../lib/api/entities'
import { categoryOf } from '../lib/categories'
import { daysSince, developerOf } from '../lib/entity'

function Sidebar({ c }: { c: Detail }) {
  const { m, tr } = useI18n()
  const fmt = useDateFormat()
  const k = m.client.infoKeys
  const updated = daysSince(c.lastCommitAt)
  const developer = developerOf(c)
  return (
    <>
      <RelatedSection kind="client" title={m.client.related} d={c} allLabel={m.client.allClients} />
      <InfoSection
        kind="client"
        d={c}
        rows={[
          { icon: Buildings, label: k.developer, value: developer && (c.author?.url ? <a href={c.author.url} target="_blank" rel="noreferrer" className="hover:text-accent">{developer}</a> : developer) },
          { icon: SquaresFour, label: k.category, value: tr(categoryOf('client', c.category?.slug).name) },
          { icon: Star, label: k.stars, value: c.stars?.toLocaleString('en-US') },
          { icon: Scales, label: k.license, value: c.license },
          { icon: Cpu, label: k.runtime, value: c.runtime },
          { icon: CalendarBlank, label: k.added, value: fmt(c.source.sourceCreatedAt) },
          { icon: ClockCounterClockwise, label: k.updated, value: updated === null ? null : m.detail.ago(updated) },
        ]}
      />
    </>
  )
}

export default function ClientDetail() {
  const { slug } = useParams()
  const { m } = useI18n()
  const state = useEntityDetail('client', slug)
  return (
    <DetailGate state={state} notFound={m.client.notFound} listHref="/clients" section={m.dirs.clients.title}>
      {(c) => (
        <>
          <EntityHeader kind="client" d={c} listTitle={m.dirs.clients.title} />
          <DetailBody
            main={
              <>
                <AboutSection d={c} />
                <section><ReadmeSection d={c} empty={m.client.noReadme} /></section>
                <section><Comments key={c.slug} target={`client:${c.slug}`} /></section>
              </>
            }
            aside={<Sidebar c={c} />}
          />
        </>
      )}
    </DetailGate>
  )
}
