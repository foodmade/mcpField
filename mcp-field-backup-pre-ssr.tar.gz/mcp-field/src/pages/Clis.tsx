import { ApiDirectory } from '../components/directory/ApiDirectory'
import { CliCard, CliRow } from '../components/directory/CliItems'
import { useI18n } from '../i18n/context'
import type { CliItem } from '../lib/api/entities'
import { cliCategories, type ViewKey } from '../lib/categories'

const Card = ({ item }: { item: CliItem }) => <CliCard c={item} />
const Row = ({ item }: { item: CliItem }) => <CliRow c={item} />
const VIEWS: ViewKey[] = ['official', 'featured', 'verified']

export default function Clis() {
  const { m } = useI18n()
  return <ApiDirectory kind="cli" text={m.dirs.cli} categories={cliCategories} views={VIEWS} Card={Card} Row={Row} />
}
