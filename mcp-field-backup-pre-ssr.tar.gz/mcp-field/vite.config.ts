import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// 所有 /api 请求转发到后端（mcp-field-crawler 项目的 src/api，默认 3100 端口）
const API_TARGET = process.env.API_TARGET ?? 'http://localhost:3100'
const apiProxy = { '/api': { target: API_TARGET, changeOrigin: true } }

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: { proxy: apiProxy },
  preview: { proxy: apiProxy },
})
