import { AnimatePresence, motion } from 'motion/react'
import { ArrowClockwise, List, SquaresFour, WarningCircle } from '@phosphor-icons/react'
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import clsx from 'clsx'
import { FaqSection } from '../Faq'
import { CountUp } from '../../fx/CountUp'
import { useI18n } from '../../i18n/context'
import type { Category, TypeOption, ViewKey } from '../../lib/categories'
import { EmptyState } from './EmptyState'
import { Pagination } from './Pagination'
import { Sidebar } from './Sidebar'
import { SortMenu } from './SortMenu'
import type { DirectoryParams } from './useDirectoryParams'

export type DirText = {
  title: string
  subBefore: string
  subAfter: string
  searchPh: string
  empty: { searchTitle: (q: string) => string; searchHint: string; catTitle: string; catHint: (c: string) => string; viewAll: string }
}

export type DirCounts = { all: number; byView: Record<ViewKey, number>; byCat: Record<string, number>; byType?: Record<string, number> }

type Props<T extends { slug: string }> = {
  text: DirText
  categories: Category[]
  views: ViewKey[]
  types?: TypeOption[]
  params: DirectoryParams
  counts: DirCounts
  /** 当前页的条目 */
  items: T[]
  /** 筛选后的总数 */
  total: number
  page: number
  pageSize: number
  Card: (p: { item: T }) => ReactNode
  Row: (p: { item: T }) => ReactNode
  /** 远程数据的加载状态；本地数据不传 */
  status?: 'loading' | 'error' | 'ready'
  onRetry?: () => void
}

function Skeleton({ layout }: { layout: 'grid' | 'list' }) {
  return (
    <div className={layout === 'grid' ? 'grid gap-4 sm:grid-cols-2 xl:grid-cols-3' : 'flex flex-col gap-2.5'} aria-hidden>
      {Array.from({ length: layout === 'grid' ? 9 : 8 }, (_, i) => (
        <div key={i} className={clsx('animate-pulse rounded-2xl border border-white/[0.06] bg-white/[0.03]', layout === 'grid' ? 'h-[150px]' : 'h-[72px]')} />
      ))}
    </div>
  )
}

function LoadError({ onRetry }: { onRetry?: () => void }) {
  const { m } = useI18n()
  return (
    <div className="flex min-h-[320px] flex-col items-center justify-center gap-3 rounded-2xl border border-white/[0.08] bg-surface px-6 text-center">
      <WarningCircle size={30} className="text-[#F2994A]" />
      <h3 className="text-lg font-semibold">{m.dir.loadError}</h3>
      <p className="max-w-[420px] text-sm text-text2">{m.dir.loadErrorHint}</p>
      {onRetry && (
        <button onClick={onRetry} className="mt-1 flex h-[38px] items-center gap-1.5 rounded-full bg-accent px-4 text-sm font-semibold text-accent-ink active:scale-95">
          <ArrowClockwise size={14} />{m.dir.retry}
        </button>
      )}
    </div>
  )
}

/** 目录页的界面骨架：头部、侧栏、排序与布局切换、列表、分页、FAQ。数据从哪来由调用方决定 */
export function DirectoryLayout<T extends { slug: string }>({ text, categories, views, types = [], params: p, counts, items, total, page, pageSize, Card, Row, status = 'ready', onRetry }: Props<T>) {
  const { m, tr } = useI18n()
  const catBySlug = useMemo(() => Object.fromEntries(categories.map((c) => [c.slug, c])), [categories])
  const [layout, setLayout] = useState<'grid' | 'list'>('grid')
  const listTop = useRef<HTMLDivElement>(null)

  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const scope = p.view ? m.dir[p.view] : p.category && catBySlug[p.category] ? tr(catBySlug[p.category].name) : null
  const typeLabel = types.find((t) => t.value === p.type)?.label
  const title = [scope, typeLabel].filter(Boolean).join(' · ') || m.dir.all
  const initialLoading = status === 'loading' && items.length === 0

  const goPage = (n: number) => {
    p.setPage(n)
    const top = listTop.current?.getBoundingClientRect().top ?? 0
    if (top < 120) window.scrollBy({ top: top - 150, behavior: 'smooth' })
  }

  useEffect(() => {
    document.title = `${title} · ${text.title} · MCP Field`
  }, [title, text.title])

  return (
    <>
      <section
        className="border-b border-white/[0.04]"
        style={{ background: 'radial-gradient(60% 220% at 20% 0%, #2B7FFF1F, transparent 60%), radial-gradient(40% 200% at 85% 0%, #3DDC9714, transparent 60%)' }}
      >
        <div className="mx-auto flex max-w-[1248px] flex-wrap items-center justify-between gap-6 px-6 pb-6 pt-7">
          <motion.div key={text.title} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}>
            <h1 className="text-[30px] font-bold leading-tight tracking-[-0.02em]">{text.title}</h1>
            <p className="mt-1.5 text-sm text-text2">
              {text.subBefore}
              <CountUp value={counts.all} format={(v) => Math.round(v).toLocaleString('en-US')} className="tabular-nums text-ink" />
              {text.subAfter}
            </p>
          </motion.div>
        </div>
      </section>

      <div className="mx-auto grid max-w-[1248px] gap-10 px-6 pb-24 pt-8 lg:grid-cols-[248px_1fr] [&>*]:min-w-0">
        <Sidebar
          categories={categories}
          searchPh={text.searchPh}
          views={views}
          types={types}
          view={p.view}
          category={p.category}
          type={p.type}
          q={p.q}
          counts={counts}
          onView={p.setView}
          onCategory={p.setCategory}
          onType={p.setType}
          onQuery={p.setQuery}
        />

        <div ref={listTop} className="flex flex-col gap-5">
          <div className="flex items-center justify-between gap-4">
            <AnimatePresence mode="wait">
              <motion.h2
                key={title}
                initial={{ opacity: 0, y: 8, filter: 'blur(6px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -8, filter: 'blur(6px)' }}
                transition={{ duration: 0.3 }}
                className="text-xl font-bold tracking-tight"
              >
                {title}
              </motion.h2>
            </AnimatePresence>
            <div className="flex items-center gap-2.5">
              <SortMenu value={p.sort} onChange={p.setSort} />
              <div className="flex gap-0.5 rounded-[9px] bg-subtle p-[3px]">
                {([['grid', SquaresFour, m.dir.grid], ['list', List, m.dir.list]] as const).map(([k, I, label]) => (
                  <button key={k} onClick={() => setLayout(k)} aria-label={label} aria-pressed={layout === k} className={clsx('relative grid size-[30px] place-items-center rounded-[7px]', layout === k ? 'text-ink' : 'text-text3 hover:text-ink')}>
                    {layout === k && <motion.span layoutId="layout-pill" className="absolute inset-0 rounded-[7px] bg-white/10" transition={{ type: 'spring', stiffness: 500, damping: 36 }} />}
                    <I size={15} className="relative" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {status === 'error' && items.length === 0 ? (
            <LoadError onRetry={onRetry} />
          ) : initialLoading ? (
            <Skeleton layout={layout} />
          ) : items.length === 0 ? (
            <EmptyState kind={p.q ? 'search' : 'category'} label={p.q || title} text={text.empty} onPrimary={() => (p.q ? p.setQuery('') : p.setCategory(null))} />
          ) : (
            <motion.div
              layout
              aria-busy={status === 'loading'}
              className={clsx(layout === 'grid' ? 'grid gap-4 sm:grid-cols-2 xl:grid-cols-3' : 'flex flex-col gap-2.5', '[&>*]:min-w-0 transition-opacity duration-200', status === 'loading' && 'opacity-60')}
            >
              <AnimatePresence mode="popLayout" initial={false}>
                {items.map((s, i) => (
                  <motion.div
                    key={`${layout}-${s.slug}`}
                    layout
                    initial={{ opacity: 0, y: 16, scale: 0.97 }}
                    animate={{ opacity: 1, y: 0, scale: 1, transition: { delay: Math.min(i, 11) * 0.025, type: 'spring', stiffness: 320, damping: 30 } }}
                    exit={{ opacity: 0, scale: 0.96, transition: { duration: 0.15 } }}
                  >
                    {layout === 'grid' ? <Card item={s} /> : <Row item={s} />}
                  </motion.div>
                ))}
              </AnimatePresence>
            </motion.div>
          )}

          {total > 0 && items.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-4 pt-4">
              <span className="text-sm text-text3">
                {m.dir.range((page - 1) * pageSize + 1, Math.min(page * pageSize, total), total.toLocaleString('en-US'))}
              </span>
              <Pagination page={page} total={totalPages} onChange={goPage} />
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-line">
        <FaqSection />
      </div>
    </>
  )
}
