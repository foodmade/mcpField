import { ApiDirectory } from '../components/directory/ApiDirectory'
import { ServerCard, ServerRow } from '../components/directory/ServerItems'
import { useI18n } from '../i18n/context'
import type { ServerItem } from '../lib/api/entities'
import { serverCategories } from '../lib/categories'

const Card = ({ item }: { item: ServerItem }) => <ServerCard s={item} />
const Row = ({ item }: { item: ServerItem }) => <ServerRow s={item} />

/** MCP 服务目录；remote 时只看远程服务 */
export default function Servers({ remote = false }: { remote?: boolean }) {
  const { m } = useI18n()
  return <ApiDirectory key={remote ? 'remote' : 'all'} kind="server" remote={remote} text={remote ? m.dirs.remote : m.dir} categories={serverCategories} Card={Card} Row={Row} />
}
