import { useSearchParams } from 'react-router'
import { SORT_KEYS, type SortKey, type ViewKey } from '../../lib/categories'

const VIEWS: ViewKey[] = ['official', 'featured', 'verified']

// 目录状态全部保存在 URL：刷新、复制链接、前进后退都能还原
export function useDirectoryParams(isCategory: (slug: string) => boolean, views: ViewKey[] = ['featured', 'verified'], types: string[] = []) {
  const [sp, setSp] = useSearchParams()
  const rawView = sp.get('view') as ViewKey | null
  const view = rawView && VIEWS.includes(rawView) && views.includes(rawView) ? rawView : null
  const rawCat = sp.get('category')
  const category = !view && rawCat && isCategory(rawCat) ? rawCat : null
  const rawSort = sp.get('sort') as SortKey | null
  const sort: SortKey = rawSort && SORT_KEYS.includes(rawSort) ? rawSort : 'hot'
  const rawType = sp.get('type')
  const type = rawType && types.includes(rawType) ? rawType : null
  const q = sp.get('q') ?? ''
  const page = Math.max(1, Number.parseInt(sp.get('page') ?? '1', 10) || 1)

  const update = (patch: Record<string, string | null>, opts: { replace?: boolean } = {}) => {
    const next = new URLSearchParams(sp)
    for (const [k, v] of Object.entries(patch)) {
      if (v === null || v === '') next.delete(k)
      else next.set(k, v)
    }
    if (!('page' in patch)) next.delete('page')
    if (next.get('sort') === 'hot') next.delete('sort')
    if (next.get('page') === '1') next.delete('page')
    setSp(next, { replace: opts.replace })
  }

  return {
    view,
    category,
    type,
    sort,
    q,
    page,
    // 快捷视图与分类互斥
    setView: (v: ViewKey | null) => update({ view: v, category: null }),
    setCategory: (c: string | null) => update({ category: c, view: null }),
    // 子类型可以和视图、分类叠加；再次点击取消
    setType: (t: string | null) => update({ type: t === type ? null : t }),
    setSort: (s: SortKey) => update({ sort: s }),
    setQuery: (v: string) => update({ q: v }, { replace: true }),
    setPage: (p: number) => update({ page: String(p) }),
    reset: () => setSp(new URLSearchParams()),
  }
}

export type DirectoryParams = ReturnType<typeof useDirectoryParams>
