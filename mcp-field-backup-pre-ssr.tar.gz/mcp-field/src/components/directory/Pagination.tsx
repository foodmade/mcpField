import { motion } from 'motion/react'
import { CaretLeft, CaretRight } from '@phosphor-icons/react'
import clsx from 'clsx'
import { useI18n } from '../../i18n/context'

function pages(cur: number, total: number): (number | '…')[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1)
  const set = new Set([1, total, cur - 1, cur, cur + 1].filter((p) => p >= 1 && p <= total))
  if (cur <= 3) [2, 3, 4].forEach((p) => set.add(p))
  if (cur >= total - 2) [total - 3, total - 2, total - 1].forEach((p) => set.add(p))
  const sorted = [...set].sort((a, b) => a - b)
  return sorted.flatMap((p, i) => (i > 0 && p - sorted[i - 1] > 1 ? ['…' as const, p] : [p]))
}

export function Pagination({ page, total, onChange }: { page: number; total: number; onChange: (p: number) => void }) {
  const { m } = useI18n()
  if (total <= 1) return null
  const btn = 'flex h-[34px] items-center justify-center gap-1 rounded-[9px] border border-white/10 text-sm transition-colors'
  return (
    <nav aria-label={m.dir.pageNav} className="flex items-center gap-1.5">
      <button disabled={page === 1} onClick={() => onChange(page - 1)} aria-label={m.dir.prev} className={clsx(btn, 'px-3 text-text2 enabled:hover:border-white/25 enabled:hover:text-ink disabled:opacity-35')}>
        <CaretLeft size={13} /><span className="hidden sm:inline">{m.dir.prev}</span>
      </button>
      {/* 手机上只显示"当前页 / 总页数"，避免页码一多就撑出屏幕 */}
      <span className="px-2 tabular-nums text-sm text-text2 sm:hidden" aria-current="page">{page} / {total}</span>
      <div className="hidden items-center gap-1.5 sm:flex">
      {pages(page, total).map((p, i) =>
        p === '…' ? (
          <span key={`e${i}`} className="px-1 text-text3">…</span>
        ) : (
          <button key={p} onClick={() => onChange(p)} aria-current={p === page ? 'page' : undefined} className={clsx(btn, 'relative w-[34px] tabular-nums', p === page ? 'border-transparent font-semibold text-accent-ink' : 'text-text2 hover:border-white/25 hover:text-ink')}>
            {p === page && <motion.span layoutId="page-pill" className="absolute inset-0 rounded-[9px] bg-accent" transition={{ type: 'spring', stiffness: 500, damping: 36 }} />}
            <span className="relative">{p}</span>
          </button>
        ),
      )}
      </div>
      <button disabled={page === total} onClick={() => onChange(page + 1)} aria-label={m.dir.next} className={clsx(btn, 'px-3 text-text2 enabled:hover:border-white/25 enabled:hover:text-ink disabled:opacity-35')}>
        <span className="hidden sm:inline">{m.dir.next}</span><CaretRight size={13} />
      </button>
    </nav>
  )
}
