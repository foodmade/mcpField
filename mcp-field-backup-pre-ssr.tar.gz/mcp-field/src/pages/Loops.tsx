import { ApiDirectory } from '../components/directory/ApiDirectory'
import { LoopCard, LoopRow } from '../components/directory/LoopItems'
import { useI18n } from '../i18n/context'
import type { LoopItem } from '../lib/api/entities'
import { loopCategories } from '../lib/categories'

const Card = ({ item }: { item: LoopItem }) => <LoopCard l={item} />
const Row = ({ item }: { item: LoopItem }) => <LoopRow l={item} />

export default function Loops() {
  const { m } = useI18n()
  return <ApiDirectory kind="loop" text={m.dirs.loops} categories={loopCategories} Card={Card} Row={Row} />
}
