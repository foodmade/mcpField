import { Categories } from '../components/Categories'
import { FaqSection } from '../components/Faq'
import { Featured } from '../components/Featured'
import { Hero } from '../components/Hero'
import { Rankings } from '../components/Rankings'
import { Container } from '../components/ui'
import { useEffect } from 'react'
import { useI18n } from '../i18n/context'

export default function Home() {
  const { m } = useI18n()
  useEffect(() => {
    document.title = m.meta.home
  }, [m])
  return (
    <>
      <Container className="pt-6">
        <Hero />
      </Container>
      <Categories />
      <Rankings />
      <Featured />
      <FaqSection />
    </>
  )
}
